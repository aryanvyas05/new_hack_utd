import '@aws-amplify/ui-react/styles.css';
export default function AmplifyProvider({ children, }: {
    children: React.ReactNode;
}): import("react").JSX.Element;
