"use strict";
'use client';
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = AmplifyProvider;
const aws_amplify_1 = require("aws-amplify");
const amplify_config_1 = __importDefault(require("@/lib/amplify-config"));
require("@aws-amplify/ui-react/styles.css");
// Configure Amplify
aws_amplify_1.Amplify.configure(amplify_config_1.default, { ssr: true });
function AmplifyProvider({ children, }) {
    return <>{children}</>;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQW1wbGlmeVByb3ZpZGVyLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiQW1wbGlmeVByb3ZpZGVyLnRzeCJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsWUFBWSxDQUFDOzs7OztBQVNiLGtDQU1DO0FBYkQsNkNBQXNDO0FBQ3RDLDBFQUFpRDtBQUNqRCw0Q0FBMEM7QUFFMUMsb0JBQW9CO0FBQ3BCLHFCQUFPLENBQUMsU0FBUyxDQUFDLHdCQUFhLEVBQUUsRUFBRSxHQUFHLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQztBQUVoRCxTQUF3QixlQUFlLENBQUMsRUFDdEMsUUFBUSxHQUdUO0lBQ0MsT0FBTyxFQUFFLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQztBQUN6QixDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgeyBBbXBsaWZ5IH0gZnJvbSAnYXdzLWFtcGxpZnknO1xuaW1wb3J0IGFtcGxpZnlDb25maWcgZnJvbSAnQC9saWIvYW1wbGlmeS1jb25maWcnO1xuaW1wb3J0ICdAYXdzLWFtcGxpZnkvdWktcmVhY3Qvc3R5bGVzLmNzcyc7XG5cbi8vIENvbmZpZ3VyZSBBbXBsaWZ5XG5BbXBsaWZ5LmNvbmZpZ3VyZShhbXBsaWZ5Q29uZmlnLCB7IHNzcjogdHJ1ZSB9KTtcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQW1wbGlmeVByb3ZpZGVyKHtcbiAgY2hpbGRyZW4sXG59OiB7XG4gIGNoaWxkcmVuOiBSZWFjdC5SZWFjdE5vZGU7XG59KSB7XG4gIHJldHVybiA8PntjaGlsZHJlbn08Lz47XG59XG4iXX0=