export default function ProtectedRoute({ children }: {
    children: React.ReactNode;
}): import("react").JSX.Element | null;
