import { get, post } from 'aws-amplify/api';
import { fetchAuthSession } from 'aws-amplify/auth';
import { OnboardingRequest, OnboardingResponse, StatusResponse, ApiError } from '@/types/api';

const API_NAME = 'VeritasOnboardAPI';

/**
 * Submit a new onboarding request
 * @param data - The onboarding request data
 * @returns Promise with the onboarding response including requestId
 * @throws Error if the request fails
 */
export async function submitOnboarding(data: OnboardingRequest): Promise<OnboardingResponse> {
  try {
    // Get the current auth session to include JWT token
    const session = await fetchAuthSession();
    const token = session.tokens?.idToken?.toString();

    if (!token) {
      throw new Error('Not authenticated. Please log in.');
    }

    const restOperation = post({
      apiName: API_NAME,
      path: '/onboard',
      options: {
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
        body: data,
      },
    });

    const response = await restOperation.response;
    const body = await response.body.json();

    if (response.statusCode !== 202) {
      const error = body as ApiError;
      throw new Error(error.message || 'Failed to submit onboarding request');
    }

    return body as OnboardingResponse;
  } catch (error) {
    console.error('Error submitting onboarding request:', error);
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('An unexpected error occurred while submitting the request');
  }
}

/**
 * Get the status of an onboarding request
 * @param requestId - The unique request ID
 * @returns Promise with the status response
 * @throws Error if the request fails
 */
export async function getOnboardingStatus(requestId: string): Promise<StatusResponse> {
  try {
    // Get the current auth session to include JWT token
    const session = await fetchAuthSession();
    const token = session.tokens?.idToken?.toString();

    if (!token) {
      throw new Error('Not authenticated. Please log in.');
    }

    const restOperation = get({
      apiName: API_NAME,
      path: `/status/${requestId}`,
      options: {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      },
    });

    const response = await restOperation.response;
    const body = await response.body.json();

    if (response.statusCode !== 200) {
      const error = body as ApiError;
      throw new Error(error.message || 'Failed to fetch onboarding status');
    }

    return body as StatusResponse;
  } catch (error) {
    console.error('Error fetching onboarding status:', error);
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('An unexpected error occurred while fetching the status');
  }
}
