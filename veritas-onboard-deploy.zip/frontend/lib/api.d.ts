import { OnboardingRequest, OnboardingResponse, StatusResponse } from '@/types/api';
/**
 * Submit a new onboarding request
 * @param data - The onboarding request data
 * @returns Promise with the onboarding response including requestId
 * @throws Error if the request fails
 */
export declare function submitOnboarding(data: OnboardingRequest): Promise<OnboardingResponse>;
/**
 * Get the status of an onboarding request
 * @param requestId - The unique request ID
 * @returns Promise with the status response
 * @throws Error if the request fails
 */
export declare function getOnboardingStatus(requestId: string): Promise<StatusResponse>;
