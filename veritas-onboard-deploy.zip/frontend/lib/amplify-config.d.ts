import { ResourcesConfig } from 'aws-amplify';
declare const amplifyConfig: ResourcesConfig;
export default amplifyConfig;
