"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.metadata = void 0;
exports.default = RootLayout;
const google_1 = require("next/font/google");
require("./globals.css");
const AmplifyProvider_1 = __importDefault(require("@/components/AmplifyProvider"));
const inter = (0, google_1.Inter)({ subsets: ['latin'] });
exports.metadata = {
    title: 'Veritas Onboard',
    description: 'AI-powered vendor onboarding platform',
};
function RootLayout({ children, }) {
    return (<html lang="en">
      <body className={inter.className}>
        <AmplifyProvider_1.default>{children}</AmplifyProvider_1.default>
      </body>
    </html>);
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibGF5b3V0LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsibGF5b3V0LnRzeCJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7QUFZQSw2QkFZQztBQXZCRCw2Q0FBeUM7QUFDekMseUJBQXVCO0FBQ3ZCLG1GQUEyRDtBQUUzRCxNQUFNLEtBQUssR0FBRyxJQUFBLGNBQUssRUFBQyxFQUFFLE9BQU8sRUFBRSxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsQ0FBQztBQUUvQixRQUFBLFFBQVEsR0FBYTtJQUNoQyxLQUFLLEVBQUUsaUJBQWlCO0lBQ3hCLFdBQVcsRUFBRSx1Q0FBdUM7Q0FDckQsQ0FBQztBQUVGLFNBQXdCLFVBQVUsQ0FBQyxFQUNqQyxRQUFRLEdBR1Q7SUFDQyxPQUFPLENBQ0wsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FDYjtNQUFBLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FDL0I7UUFBQSxDQUFDLHlCQUFlLENBQUMsQ0FBQyxRQUFRLENBQUMsRUFBRSx5QkFBZSxDQUM5QztNQUFBLEVBQUUsSUFBSSxDQUNSO0lBQUEsRUFBRSxJQUFJLENBQUMsQ0FDUixDQUFDO0FBQ0osQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB0eXBlIHsgTWV0YWRhdGEgfSBmcm9tICduZXh0JztcbmltcG9ydCB7IEludGVyIH0gZnJvbSAnbmV4dC9mb250L2dvb2dsZSc7XG5pbXBvcnQgJy4vZ2xvYmFscy5jc3MnO1xuaW1wb3J0IEFtcGxpZnlQcm92aWRlciBmcm9tICdAL2NvbXBvbmVudHMvQW1wbGlmeVByb3ZpZGVyJztcblxuY29uc3QgaW50ZXIgPSBJbnRlcih7IHN1YnNldHM6IFsnbGF0aW4nXSB9KTtcblxuZXhwb3J0IGNvbnN0IG1ldGFkYXRhOiBNZXRhZGF0YSA9IHtcbiAgdGl0bGU6ICdWZXJpdGFzIE9uYm9hcmQnLFxuICBkZXNjcmlwdGlvbjogJ0FJLXBvd2VyZWQgdmVuZG9yIG9uYm9hcmRpbmcgcGxhdGZvcm0nLFxufTtcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gUm9vdExheW91dCh7XG4gIGNoaWxkcmVuLFxufToge1xuICBjaGlsZHJlbjogUmVhY3QuUmVhY3ROb2RlO1xufSkge1xuICByZXR1cm4gKFxuICAgIDxodG1sIGxhbmc9XCJlblwiPlxuICAgICAgPGJvZHkgY2xhc3NOYW1lPXtpbnRlci5jbGFzc05hbWV9PlxuICAgICAgICA8QW1wbGlmeVByb3ZpZGVyPntjaGlsZHJlbn08L0FtcGxpZnlQcm92aWRlcj5cbiAgICAgIDwvYm9keT5cbiAgICA8L2h0bWw+XG4gICk7XG59XG4iXX0=