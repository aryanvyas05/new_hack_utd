'use client';

import { Authenticator } from '@aws-amplify/ui-react';
import { useRouter } from 'next/navigation';
import { useEffect } from 'react';
import { Heading, View, Text, Button } from '@aws-amplify/ui-react';

export default function Home() {
  const router = useRouter();

  return (
    <Authenticator
      signUpAttributes={['email']}
      formFields={{
        signUp: {
          email: {
            order: 1,
            placeholder: 'Enter your email',
            isRequired: true,
          },
          password: {
            order: 2,
            placeholder: 'Enter your password',
            isRequired: true,
          },
          confirm_password: {
            order: 3,
            placeholder: 'Confirm your password',
            isRequired: true,
          },
        },
      }}
    >
      {({ signOut, user }) => (
        <View padding="2rem" maxWidth="1200px" margin="0 auto">
          <View
            display="flex"
            justifyContent="space-between"
            alignItems="center"
            marginBottom="2rem"
            padding="1rem"
            backgroundColor="var(--amplify-colors-background-secondary)"
            borderRadius="8px"
          >
            <View>
              <Heading level={2}>Welcome, {user?.signInDetails?.loginId}</Heading>
              <Text>You are successfully signed in to Veritas Onboard</Text>
            </View>
            <Button onClick={signOut} variation="link">
              Sign Out
            </Button>
          </View>

          <View textAlign="center" marginTop="3rem">
            <Heading level={1} marginBottom="1rem">
              Veritas Onboard
            </Heading>
            <Text fontSize="1.2rem" marginBottom="2rem">
              AI-Powered Vendor Onboarding Platform
            </Text>
            <Text marginBottom="2rem">
              Streamline your vendor onboarding process with automated fraud detection,
              PII protection, and intelligent risk assessment.
            </Text>
            <Button
              variation="primary"
              size="large"
              onClick={() => router.push('/onboard')}
            >
              Start Onboarding Process
            </Button>
          </View>
        </View>
      )}
    </Authenticator>
  );
}
