export default function StatusPage(): import("react").JSX.Element;
