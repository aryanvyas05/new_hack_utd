'use client';

import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { getOnboardingStatus } from '@/lib/api';
import { StatusResponse } from '@/types/api';
import {
  View,
  Heading,
  Text,
  Badge,
  Card,
  Loader,
  Alert,
  Button,
  Divider,
} from '@aws-amplify/ui-react';
import ProtectedRoute from '@/components/ProtectedRoute';

function StatusContent() {
  const params = useParams();
  const router = useRouter();
  const requestId = params.requestId as string;

  const [status, setStatus] = useState<StatusResponse | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (requestId) {
      fetchStatus();
    }
  }, [requestId]);

  const fetchStatus = async () => {
    try {
      setIsLoading(true);
      setError(null);
      const data = await getOnboardingStatus(requestId);
      setStatus(data);
    } catch (err) {
      console.error('Error fetching status:', err);
      setError(err instanceof Error ? err.message : 'Failed to fetch status');
    } finally {
      setIsLoading(false);
    }
  };

  const getStatusBadge = (statusValue: string) => {
    const statusConfig = {
      SUBMITTED: { variation: 'info' as const, label: 'Submitted' },
      APPROVED: { variation: 'success' as const, label: 'Approved' },
      MANUAL_REVIEW: { variation: 'warning' as const, label: 'Manual Review' },
      REJECTED: { variation: 'error' as const, label: 'Rejected' },
    };

    const config = statusConfig[statusValue as keyof typeof statusConfig] || {
      variation: 'info' as const,
      label: statusValue,
    };

    return <Badge variation={config.variation}>{config.label}</Badge>;
  };

  const getStatusMessage = (statusValue: string) => {
    const messages = {
      SUBMITTED:
        'Your onboarding request has been submitted and is currently being processed.',
      APPROVED:
        'Congratulations! Your onboarding request has been approved. You can now proceed with the next steps.',
      MANUAL_REVIEW:
        'Your onboarding request requires manual review by our team. We will contact you shortly with an update.',
      REJECTED:
        'Unfortunately, your onboarding request has been rejected. Please contact support for more information.',
    };

    return messages[statusValue as keyof typeof messages] || 'Status unknown';
  };

  const formatTimestamp = (timestamp: number) => {
    return new Date(timestamp * 1000).toLocaleString();
  };

  const getRiskLevel = (score: number) => {
    if (score > 0.8) return { label: 'High', color: 'red' };
    if (score > 0.5) return { label: 'Medium', color: 'orange' };
    return { label: 'Low', color: 'green' };
  };

  if (isLoading) {
    return (
      <View
        display="flex"
        justifyContent="center"
        alignItems="center"
        height="100vh"
      >
        <Loader size="large" />
        <Text marginTop="1rem">Loading status...</Text>
      </View>
    );
  }

  if (error) {
    return (
      <View padding="2rem" maxWidth="800px" margin="0 auto">
        <Alert variation="error" isDismissible={false} marginBottom="1rem">
          {error}
        </Alert>
        <Button onClick={() => router.push('/')}>Return to Home</Button>
      </View>
    );
  }

  if (!status) {
    return (
      <View padding="2rem" maxWidth="800px" margin="0 auto">
        <Alert variation="warning" isDismissible={false}>
          No status information available
        </Alert>
      </View>
    );
  }

  return (
    <View padding="2rem" maxWidth="1000px" margin="0 auto">
      <View marginBottom="2rem">
        <Button onClick={() => router.push('/')} variation="link" marginBottom="1rem">
          ← Back to Home
        </Button>
        <Heading level={1}>Onboarding Request Status</Heading>
      </View>

      <Card marginBottom="2rem">
        <View display="flex" justifyContent="space-between" alignItems="center" marginBottom="1rem">
          <Heading level={3}>Request Information</Heading>
          {getStatusBadge(status.status)}
        </View>

        <Alert variation="info" isDismissible={false} marginBottom="1rem">
          {getStatusMessage(status.status)}
        </Alert>

        <View marginBottom="1rem">
          <Text fontWeight="bold">Request ID:</Text>
          <Text fontFamily="monospace">{status.requestId}</Text>
        </View>

        <View marginBottom="1rem">
          <Text fontWeight="bold">Vendor Name:</Text>
          <Text>{status.vendorName}</Text>
        </View>

        <View marginBottom="1rem">
          <Text fontWeight="bold">Contact Email:</Text>
          <Text>{status.contactEmail}</Text>
        </View>

        <View marginBottom="1rem">
          <Text fontWeight="bold">Submitted:</Text>
          <Text>{formatTimestamp(status.createdAt)}</Text>
        </View>

        <View>
          <Text fontWeight="bold">Last Updated:</Text>
          <Text>{formatTimestamp(status.updatedAt)}</Text>
        </View>
      </Card>

      {status.riskScores && (
        <Card marginBottom="2rem">
          <Heading level={3} marginBottom="1rem">
            Risk Assessment
          </Heading>

          <View marginBottom="1rem">
            <View display="flex" justifyContent="space-between" alignItems="center">
              <Text fontWeight="bold">Combined Risk Score:</Text>
              <View display="flex" alignItems="center" gap="0.5rem">
                <Text fontSize="1.2rem" fontWeight="bold">
                  {(status.riskScores.combinedRiskScore * 100).toFixed(1)}%
                </Text>
                <Badge
                  variation={
                    getRiskLevel(status.riskScores.combinedRiskScore).label === 'High'
                      ? 'error'
                      : getRiskLevel(status.riskScores.combinedRiskScore).label === 'Medium'
                      ? 'warning'
                      : 'success'
                  }
                >
                  {getRiskLevel(status.riskScores.combinedRiskScore).label} Risk
                </Badge>
              </View>
            </View>
          </View>

          <Divider marginTop="1rem" marginBottom="1rem" />

          <View marginBottom="0.5rem">
            <View display="flex" justifyContent="space-between">
              <Text>Fraud Score:</Text>
              <Text fontWeight="bold">
                {(status.riskScores.fraudScore * 100).toFixed(1)}%
              </Text>
            </View>
          </View>

          <View>
            <View display="flex" justifyContent="space-between">
              <Text>Content Risk Score:</Text>
              <Text fontWeight="bold">
                {(status.riskScores.contentRiskScore * 100).toFixed(1)}%
              </Text>
            </View>
          </View>
        </Card>
      )}

      {status.fraudDetails && (
        <Card marginBottom="2rem">
          <Heading level={3} marginBottom="1rem">
            Fraud Detection Details
          </Heading>

          <View marginBottom="1rem">
            <Text fontWeight="bold">Model Version:</Text>
            <Text>{status.fraudDetails.modelVersion}</Text>
          </View>

          {status.fraudDetails.riskFactors && status.fraudDetails.riskFactors.length > 0 && (
            <View>
              <Text fontWeight="bold" marginBottom="0.5rem">
                Risk Factors:
              </Text>
              <View display="flex" gap="0.5rem" flexWrap="wrap">
                {status.fraudDetails.riskFactors.map((factor, index) => (
                  <Badge key={index} variation="warning">
                    {factor}
                  </Badge>
                ))}
              </View>
            </View>
          )}
        </Card>
      )}

      {status.sentimentDetails && (
        <Card>
          <Heading level={3} marginBottom="1rem">
            Sentiment Analysis
          </Heading>

          <View marginBottom="1rem">
            <Text fontWeight="bold">Overall Sentiment:</Text>
            <Badge
              variation={
                status.sentimentDetails.sentiment === 'POSITIVE'
                  ? 'success'
                  : status.sentimentDetails.sentiment === 'NEGATIVE'
                  ? 'error'
                  : 'warning'
              }
            >
              {status.sentimentDetails.sentiment}
            </Badge>
          </View>

          {status.sentimentDetails.keyPhrases && status.sentimentDetails.keyPhrases.length > 0 && (
            <View>
              <Text fontWeight="bold" marginBottom="0.5rem">
                Key Phrases:
              </Text>
              <View display="flex" gap="0.5rem" flexWrap="wrap">
                {status.sentimentDetails.keyPhrases.map((phrase, index) => (
                  <Badge key={index} variation="info">
                    {phrase}
                  </Badge>
                ))}
              </View>
            </View>
          )}
        </Card>
      )}

      <View marginTop="2rem" textAlign="center">
        <Button onClick={fetchStatus} variation="primary">
          Refresh Status
        </Button>
      </View>
    </View>
  );
}

export default function StatusPage() {
  return (
    <ProtectedRoute>
      <StatusContent />
    </ProtectedRoute>
  );
}
