"use strict";
'use client';
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = Home;
const ui_react_1 = require("@aws-amplify/ui-react");
const navigation_1 = require("next/navigation");
const ui_react_2 = require("@aws-amplify/ui-react");
function Home() {
    const router = (0, navigation_1.useRouter)();
    return (<ui_react_1.Authenticator signUpAttributes={['email']} formFields={{
            signUp: {
                email: {
                    order: 1,
                    placeholder: 'Enter your email',
                    isRequired: true,
                },
                password: {
                    order: 2,
                    placeholder: 'Enter your password',
                    isRequired: true,
                },
                confirm_password: {
                    order: 3,
                    placeholder: 'Confirm your password',
                    isRequired: true,
                },
            },
        }}>
      {({ signOut, user }) => (<ui_react_2.View padding="2rem" maxWidth="1200px" margin="0 auto">
          <ui_react_2.View display="flex" justifyContent="space-between" alignItems="center" marginBottom="2rem" padding="1rem" backgroundColor="var(--amplify-colors-background-secondary)" borderRadius="8px">
            <ui_react_2.View>
              <ui_react_2.Heading level={2}>Welcome, {user?.signInDetails?.loginId}</ui_react_2.Heading>
              <ui_react_2.Text>You are successfully signed in to Veritas Onboard</ui_react_2.Text>
            </ui_react_2.View>
            <ui_react_2.Button onClick={signOut} variation="link">
              Sign Out
            </ui_react_2.Button>
          </ui_react_2.View>

          <ui_react_2.View textAlign="center" marginTop="3rem">
            <ui_react_2.Heading level={1} marginBottom="1rem">
              Veritas Onboard
            </ui_react_2.Heading>
            <ui_react_2.Text fontSize="1.2rem" marginBottom="2rem">
              AI-Powered Vendor Onboarding Platform
            </ui_react_2.Text>
            <ui_react_2.Text marginBottom="2rem">
              Streamline your vendor onboarding process with automated fraud detection,
              PII protection, and intelligent risk assessment.
            </ui_react_2.Text>
            <ui_react_2.Button variation="primary" size="large" onClick={() => router.push('/onboard')}>
              Start Onboarding Process
            </ui_react_2.Button>
          </ui_react_2.View>
        </ui_react_2.View>)}
    </ui_react_1.Authenticator>);
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGFnZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbInBhZ2UudHN4Il0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQSxZQUFZLENBQUM7O0FBT2IsdUJBcUVDO0FBMUVELG9EQUFzRDtBQUN0RCxnREFBNEM7QUFFNUMsb0RBQW9FO0FBRXBFLFNBQXdCLElBQUk7SUFDMUIsTUFBTSxNQUFNLEdBQUcsSUFBQSxzQkFBUyxHQUFFLENBQUM7SUFFM0IsT0FBTyxDQUNMLENBQUMsd0JBQWEsQ0FDWixnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FDNUIsVUFBVSxDQUFDLENBQUM7WUFDVixNQUFNLEVBQUU7Z0JBQ04sS0FBSyxFQUFFO29CQUNMLEtBQUssRUFBRSxDQUFDO29CQUNSLFdBQVcsRUFBRSxrQkFBa0I7b0JBQy9CLFVBQVUsRUFBRSxJQUFJO2lCQUNqQjtnQkFDRCxRQUFRLEVBQUU7b0JBQ1IsS0FBSyxFQUFFLENBQUM7b0JBQ1IsV0FBVyxFQUFFLHFCQUFxQjtvQkFDbEMsVUFBVSxFQUFFLElBQUk7aUJBQ2pCO2dCQUNELGdCQUFnQixFQUFFO29CQUNoQixLQUFLLEVBQUUsQ0FBQztvQkFDUixXQUFXLEVBQUUsdUJBQXVCO29CQUNwQyxVQUFVLEVBQUUsSUFBSTtpQkFDakI7YUFDRjtTQUNGLENBQUMsQ0FFRjtNQUFBLENBQUMsQ0FBQyxFQUFFLE9BQU8sRUFBRSxJQUFJLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FDdEIsQ0FBQyxlQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQ3BEO1VBQUEsQ0FBQyxlQUFJLENBQ0gsT0FBTyxDQUFDLE1BQU0sQ0FDZCxjQUFjLENBQUMsZUFBZSxDQUM5QixVQUFVLENBQUMsUUFBUSxDQUNuQixZQUFZLENBQUMsTUFBTSxDQUNuQixPQUFPLENBQUMsTUFBTSxDQUNkLGVBQWUsQ0FBQyw0Q0FBNEMsQ0FDNUQsWUFBWSxDQUFDLEtBQUssQ0FFbEI7WUFBQSxDQUFDLGVBQUksQ0FDSDtjQUFBLENBQUMsa0JBQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFFLGFBQWEsRUFBRSxPQUFPLENBQUMsRUFBRSxrQkFBTyxDQUNuRTtjQUFBLENBQUMsZUFBSSxDQUFDLGlEQUFpRCxFQUFFLGVBQUksQ0FDL0Q7WUFBQSxFQUFFLGVBQUksQ0FDTjtZQUFBLENBQUMsaUJBQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUN4Qzs7WUFDRixFQUFFLGlCQUFNLENBQ1Y7VUFBQSxFQUFFLGVBQUksQ0FFTjs7VUFBQSxDQUFDLGVBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQ3ZDO1lBQUEsQ0FBQyxrQkFBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQ3BDOztZQUNGLEVBQUUsa0JBQU8sQ0FDVDtZQUFBLENBQUMsZUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FDekM7O1lBQ0YsRUFBRSxlQUFJLENBQ047WUFBQSxDQUFDLGVBQUksQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUN2Qjs7O1lBRUYsRUFBRSxlQUFJLENBQ047WUFBQSxDQUFDLGlCQUFNLENBQ0wsU0FBUyxDQUFDLFNBQVMsQ0FDbkIsSUFBSSxDQUFDLE9BQU8sQ0FDWixPQUFPLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBRXZDOztZQUNGLEVBQUUsaUJBQU0sQ0FDVjtVQUFBLEVBQUUsZUFBSSxDQUNSO1FBQUEsRUFBRSxlQUFJLENBQUMsQ0FDUixDQUNIO0lBQUEsRUFBRSx3QkFBYSxDQUFDLENBQ2pCLENBQUM7QUFDSixDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgeyBBdXRoZW50aWNhdG9yIH0gZnJvbSAnQGF3cy1hbXBsaWZ5L3VpLXJlYWN0JztcbmltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gJ25leHQvbmF2aWdhdGlvbic7XG5pbXBvcnQgeyB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBIZWFkaW5nLCBWaWV3LCBUZXh0LCBCdXR0b24gfSBmcm9tICdAYXdzLWFtcGxpZnkvdWktcmVhY3QnO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBIb21lKCkge1xuICBjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKTtcblxuICByZXR1cm4gKFxuICAgIDxBdXRoZW50aWNhdG9yXG4gICAgICBzaWduVXBBdHRyaWJ1dGVzPXtbJ2VtYWlsJ119XG4gICAgICBmb3JtRmllbGRzPXt7XG4gICAgICAgIHNpZ25VcDoge1xuICAgICAgICAgIGVtYWlsOiB7XG4gICAgICAgICAgICBvcmRlcjogMSxcbiAgICAgICAgICAgIHBsYWNlaG9sZGVyOiAnRW50ZXIgeW91ciBlbWFpbCcsXG4gICAgICAgICAgICBpc1JlcXVpcmVkOiB0cnVlLFxuICAgICAgICAgIH0sXG4gICAgICAgICAgcGFzc3dvcmQ6IHtcbiAgICAgICAgICAgIG9yZGVyOiAyLFxuICAgICAgICAgICAgcGxhY2Vob2xkZXI6ICdFbnRlciB5b3VyIHBhc3N3b3JkJyxcbiAgICAgICAgICAgIGlzUmVxdWlyZWQ6IHRydWUsXG4gICAgICAgICAgfSxcbiAgICAgICAgICBjb25maXJtX3Bhc3N3b3JkOiB7XG4gICAgICAgICAgICBvcmRlcjogMyxcbiAgICAgICAgICAgIHBsYWNlaG9sZGVyOiAnQ29uZmlybSB5b3VyIHBhc3N3b3JkJyxcbiAgICAgICAgICAgIGlzUmVxdWlyZWQ6IHRydWUsXG4gICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICAgIH19XG4gICAgPlxuICAgICAgeyh7IHNpZ25PdXQsIHVzZXIgfSkgPT4gKFxuICAgICAgICA8VmlldyBwYWRkaW5nPVwiMnJlbVwiIG1heFdpZHRoPVwiMTIwMHB4XCIgbWFyZ2luPVwiMCBhdXRvXCI+XG4gICAgICAgICAgPFZpZXdcbiAgICAgICAgICAgIGRpc3BsYXk9XCJmbGV4XCJcbiAgICAgICAgICAgIGp1c3RpZnlDb250ZW50PVwic3BhY2UtYmV0d2VlblwiXG4gICAgICAgICAgICBhbGlnbkl0ZW1zPVwiY2VudGVyXCJcbiAgICAgICAgICAgIG1hcmdpbkJvdHRvbT1cIjJyZW1cIlxuICAgICAgICAgICAgcGFkZGluZz1cIjFyZW1cIlxuICAgICAgICAgICAgYmFja2dyb3VuZENvbG9yPVwidmFyKC0tYW1wbGlmeS1jb2xvcnMtYmFja2dyb3VuZC1zZWNvbmRhcnkpXCJcbiAgICAgICAgICAgIGJvcmRlclJhZGl1cz1cIjhweFwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPFZpZXc+XG4gICAgICAgICAgICAgIDxIZWFkaW5nIGxldmVsPXsyfT5XZWxjb21lLCB7dXNlcj8uc2lnbkluRGV0YWlscz8ubG9naW5JZH08L0hlYWRpbmc+XG4gICAgICAgICAgICAgIDxUZXh0PllvdSBhcmUgc3VjY2Vzc2Z1bGx5IHNpZ25lZCBpbiB0byBWZXJpdGFzIE9uYm9hcmQ8L1RleHQ+XG4gICAgICAgICAgICA8L1ZpZXc+XG4gICAgICAgICAgICA8QnV0dG9uIG9uQ2xpY2s9e3NpZ25PdXR9IHZhcmlhdGlvbj1cImxpbmtcIj5cbiAgICAgICAgICAgICAgU2lnbiBPdXRcbiAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgIDwvVmlldz5cblxuICAgICAgICAgIDxWaWV3IHRleHRBbGlnbj1cImNlbnRlclwiIG1hcmdpblRvcD1cIjNyZW1cIj5cbiAgICAgICAgICAgIDxIZWFkaW5nIGxldmVsPXsxfSBtYXJnaW5Cb3R0b209XCIxcmVtXCI+XG4gICAgICAgICAgICAgIFZlcml0YXMgT25ib2FyZFxuICAgICAgICAgICAgPC9IZWFkaW5nPlxuICAgICAgICAgICAgPFRleHQgZm9udFNpemU9XCIxLjJyZW1cIiBtYXJnaW5Cb3R0b209XCIycmVtXCI+XG4gICAgICAgICAgICAgIEFJLVBvd2VyZWQgVmVuZG9yIE9uYm9hcmRpbmcgUGxhdGZvcm1cbiAgICAgICAgICAgIDwvVGV4dD5cbiAgICAgICAgICAgIDxUZXh0IG1hcmdpbkJvdHRvbT1cIjJyZW1cIj5cbiAgICAgICAgICAgICAgU3RyZWFtbGluZSB5b3VyIHZlbmRvciBvbmJvYXJkaW5nIHByb2Nlc3Mgd2l0aCBhdXRvbWF0ZWQgZnJhdWQgZGV0ZWN0aW9uLFxuICAgICAgICAgICAgICBQSUkgcHJvdGVjdGlvbiwgYW5kIGludGVsbGlnZW50IHJpc2sgYXNzZXNzbWVudC5cbiAgICAgICAgICAgIDwvVGV4dD5cbiAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgdmFyaWF0aW9uPVwicHJpbWFyeVwiXG4gICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHJvdXRlci5wdXNoKCcvb25ib2FyZCcpfVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICBTdGFydCBPbmJvYXJkaW5nIFByb2Nlc3NcbiAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgIDwvVmlldz5cbiAgICAgICAgPC9WaWV3PlxuICAgICAgKX1cbiAgICA8L0F1dGhlbnRpY2F0b3I+XG4gICk7XG59XG4iXX0=