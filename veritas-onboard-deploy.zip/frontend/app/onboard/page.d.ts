export default function OnboardPage(): import("react").JSX.Element;
