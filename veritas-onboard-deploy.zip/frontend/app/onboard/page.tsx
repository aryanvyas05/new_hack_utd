'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { submitOnboarding } from '@/lib/api';
import { OnboardingRequest } from '@/types/api';
import { Button, TextField, TextAreaField, Heading, View, Alert } from '@aws-amplify/ui-react';
import ProtectedRoute from '@/components/ProtectedRoute';

function OnboardForm() {
  const router = useRouter();
  const [formData, setFormData] = useState<OnboardingRequest>({
    vendorName: '',
    contactEmail: '',
    businessDescription: '',
    taxId: '',
  });
  const [errors, setErrors] = useState<Partial<Record<keyof OnboardingRequest, string>>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);

  const validateEmail = (email: string): boolean => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const validateTaxId = (taxId: string): boolean => {
    // Basic validation for US EIN format (XX-XXXXXXX) or SSN format (XXX-XX-XXXX)
    const taxIdRegex = /^\d{2}-\d{7}$|^\d{3}-\d{2}-\d{4}$/;
    return taxIdRegex.test(taxId);
  };

  const validateForm = (): boolean => {
    const newErrors: Partial<Record<keyof OnboardingRequest, string>> = {};

    if (!formData.vendorName.trim()) {
      newErrors.vendorName = 'Vendor name is required';
    }

    if (!formData.contactEmail.trim()) {
      newErrors.contactEmail = 'Contact email is required';
    } else if (!validateEmail(formData.contactEmail)) {
      newErrors.contactEmail = 'Please enter a valid email address';
    }

    if (!formData.businessDescription.trim()) {
      newErrors.businessDescription = 'Business description is required';
    }

    if (!formData.taxId.trim()) {
      newErrors.taxId = 'Tax ID is required';
    } else if (!validateTaxId(formData.taxId)) {
      newErrors.taxId = 'Please enter a valid Tax ID (XX-XXXXXXX or XXX-XX-XXXX)';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitError(null);

    if (!validateForm()) {
      return;
    }

    setIsSubmitting(true);

    try {
      const response = await submitOnboarding(formData);
      // Redirect to status page with the request ID
      router.push(`/status/${response.requestId}`);
    } catch (error) {
      console.error('Submission error:', error);
      setSubmitError(
        error instanceof Error ? error.message : 'Failed to submit onboarding request. Please try again.'
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleChange = (field: keyof OnboardingRequest, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    // Clear error for this field when user starts typing
    if (errors[field]) {
      setErrors((prev) => ({ ...prev, [field]: undefined }));
    }
  };

  return (
    <View padding="2rem" maxWidth="800px" margin="0 auto">
      <Heading level={1} marginBottom="2rem">
        Vendor Onboarding
      </Heading>

      {submitError && (
        <Alert variation="error" isDismissible onDismiss={() => setSubmitError(null)} marginBottom="1rem">
          {submitError}
        </Alert>
      )}

      <form onSubmit={handleSubmit}>
        <View marginBottom="1.5rem">
          <TextField
            label="Vendor Name"
            placeholder="Enter vendor or company name"
            value={formData.vendorName}
            onChange={(e) => handleChange('vendorName', e.target.value)}
            hasError={!!errors.vendorName}
            errorMessage={errors.vendorName}
            isRequired
          />
        </View>

        <View marginBottom="1.5rem">
          <TextField
            label="Contact Email"
            type="email"
            placeholder="contact@example.com"
            value={formData.contactEmail}
            onChange={(e) => handleChange('contactEmail', e.target.value)}
            hasError={!!errors.contactEmail}
            errorMessage={errors.contactEmail}
            isRequired
          />
        </View>

        <View marginBottom="1.5rem">
          <TextAreaField
            label="Business Description"
            placeholder="Describe your business, products, and services..."
            value={formData.businessDescription}
            onChange={(e) => handleChange('businessDescription', e.target.value)}
            hasError={!!errors.businessDescription}
            errorMessage={errors.businessDescription}
            rows={6}
            isRequired
          />
        </View>

        <View marginBottom="2rem">
          <TextField
            label="Tax ID"
            placeholder="XX-XXXXXXX or XXX-XX-XXXX"
            value={formData.taxId}
            onChange={(e) => handleChange('taxId', e.target.value)}
            hasError={!!errors.taxId}
            errorMessage={errors.taxId}
            isRequired
          />
        </View>

        <Button type="submit" variation="primary" isLoading={isSubmitting} isFullWidth>
          Submit Onboarding Request
        </Button>
      </form>
    </View>
  );
}

export default function OnboardPage() {
  return (
    <ProtectedRoute>
      <OnboardForm />
    </ProtectedRoute>
  );
}
