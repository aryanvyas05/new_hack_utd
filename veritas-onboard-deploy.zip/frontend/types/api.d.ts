export interface OnboardingRequest {
    vendorName: string;
    contactEmail: string;
    businessDescription: string;
    taxId: string;
}
export interface OnboardingResponse {
    requestId: string;
    status: 'SUBMITTED';
    message: string;
}
export interface StatusResponse {
    requestId: string;
    status: 'SUBMITTED' | 'APPROVED' | 'MANUAL_REVIEW' | 'REJECTED';
    vendorName: string;
    contactEmail: string;
    businessDescription: string;
    createdAt: number;
    updatedAt: number;
    riskScores?: {
        fraudScore: number;
        contentRiskScore: number;
        combinedRiskScore: number;
    };
    fraudDetails?: {
        modelVersion: string;
        riskFactors: string[];
    };
    sentimentDetails?: {
        sentiment: string;
        keyPhrases: string[];
    };
}
export interface ApiError {
    message: string;
    statusCode: number;
}
