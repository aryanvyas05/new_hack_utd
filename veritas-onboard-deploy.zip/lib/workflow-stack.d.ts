import * as cdk from 'aws-cdk-lib';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import * as dynamodb from 'aws-cdk-lib/aws-dynamodb';
import * as sns from 'aws-cdk-lib/aws-sns';
import * as sfn from 'aws-cdk-lib/aws-stepfunctions';
import { Construct } from 'constructs';
export interface WorkflowStackProps extends cdk.StackProps {
    table: dynamodb.Table;
}
export declare class WorkflowStack extends cdk.Stack {
    readonly stateMachine: sfn.StateMachine;
    readonly adminTopic: sns.Topic;
    private readonly redactPiiFunction;
    private readonly fraudDetectorFunction;
    private readonly comprehendFunction;
    private readonly combineScoresFunction;
    private readonly saveDynamoFunction;
    private readonly notifyAdminFunction;
    /**
     * Get all Lambda functions for monitoring
     */
    getAllLambdaFunctions(): lambda.Function[];
    private readonly detectorName;
    private readonly eventTypeName;
    constructor(scope: Construct, id: string, props: WorkflowStackProps);
    /**
     * Create Redact PII Lambda function
     * Memory: 512 MB, Timeout: 60 seconds
     */
    private createRedactPiiFunction;
    /**
     * Create Fraud Detector Lambda function
     * Memory: 512 MB, Timeout: 60 seconds
     * Updated with model details (subtask 13.3)
     */
    private createFraudDetectorFunction;
    /**
     * Create Comprehend Lambda function
     * Memory: 512 MB, Timeout: 60 seconds
     */
    private createComprehendFunction;
    /**
     * Create Combine Scores Lambda function
     * Memory: 256 MB, Timeout: 30 seconds
     */
    private createCombineScoresFunction;
    /**
     * Create Save to DynamoDB Lambda function
     * Memory: 256 MB, Timeout: 30 seconds
     */
    private createSaveDynamoFunction;
    /**
     * Create Notify Admin Lambda function
     * Memory: 256 MB, Timeout: 30 seconds
     */
    private createNotifyAdminFunction;
    /**
     * Create Step Functions state machine with complete workflow
     * Includes error handling and retry configuration (subtasks 9.3 and 9.4)
     */
    private createStateMachine;
    /**
     * Create Fraud Detector event type and variables (subtask 13.1)
     * Uses CloudFormation custom resources to configure Fraud Detector
     */
    private createFraudDetectorResources;
}
