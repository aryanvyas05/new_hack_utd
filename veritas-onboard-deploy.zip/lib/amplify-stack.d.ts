import * as cdk from 'aws-cdk-lib';
import * as cognito from 'aws-cdk-lib/aws-cognito';
import * as amplify from 'aws-cdk-lib/aws-amplify';
import { Construct } from 'constructs';
export interface AmplifyStackProps extends cdk.StackProps {
    apiEndpoint?: string;
    githubRepo?: string;
    githubBranch?: string;
    githubToken?: string;
}
export declare class AmplifyStack extends cdk.Stack {
    readonly userPool: cognito.UserPool;
    readonly userPoolClient: cognito.UserPoolClient;
    readonly amplifyApp?: amplify.CfnApp;
    constructor(scope: Construct, id: string, props: AmplifyStackProps);
    private createAmplifyServiceRole;
}
