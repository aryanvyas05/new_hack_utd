import * as cdk from 'aws-cdk-lib';
import * as apigateway from 'aws-cdk-lib/aws-apigateway';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import * as sfn from 'aws-cdk-lib/aws-stepfunctions';
import * as dynamodb from 'aws-cdk-lib/aws-dynamodb';
import * as cognito from 'aws-cdk-lib/aws-cognito';
import { Construct } from 'constructs';
export interface ApiStackProps extends cdk.StackProps {
    stateMachine: sfn.StateMachine;
    table?: dynamodb.Table;
    userPool?: cognito.UserPool;
}
export declare class ApiStack extends cdk.Stack {
    readonly apiEndpoint: string;
    readonly api: apigateway.RestApi;
    private readonly startWorkflowFunction;
    private readonly queryStatusFunction;
    private readonly quicksightDataFunction;
    /**
     * Get all Lambda functions for monitoring
     */
    getAllLambdaFunctions(): lambda.Function[];
    constructor(scope: Construct, id: string, props: ApiStackProps);
    /**
     * Create Start Workflow Lambda function (subtask 10.2)
     */
    private createStartWorkflowFunction;
    /**
     * Create Query Status Lambda function
     */
    private createQueryStatusFunction;
    /**
     * Create QuickSight Data Lambda function (subtask 15.1)
     */
    private createQuickSightDataFunction;
    /**
     * Configure API Gateway endpoints and integrations (subtask 10.3)
     */
    private configureEndpoints;
    /**
     * Create request model for POST /onboard validation
     */
    private createOnboardRequestModel;
    /**
     * Implement AWS WAF with security rules (subtask 10.4)
     */
    private configureWAF;
}
