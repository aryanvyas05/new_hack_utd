import * as cdk from 'aws-cdk-lib';
import * as sns from 'aws-cdk-lib/aws-sns';
import * as apigateway from 'aws-cdk-lib/aws-apigateway';
import * as sfn from 'aws-cdk-lib/aws-stepfunctions';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import { Construct } from 'constructs';
export interface MonitoringStackProps extends cdk.StackProps {
    api: apigateway.RestApi;
    stateMachine: sfn.StateMachine;
    lambdaFunctions: lambda.Function[];
    alarmEmail?: string;
}
export declare class MonitoringStack extends cdk.Stack {
    readonly alarmTopic: sns.Topic;
    constructor(scope: Construct, id: string, props: MonitoringStackProps);
    /**
     * Create alarm for API Gateway 5XX error rate > 1% for 5 minutes
     */
    private createApiGatewayAlarms;
    /**
     * Create alarm for Step Functions execution failure rate > 5% for 5 minutes
     */
    private createStepFunctionsAlarms;
    /**
     * Create alarm for Lambda error rate > 5% for 5 minutes
     */
    private createLambdaAlarms;
}
