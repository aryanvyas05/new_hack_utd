import json
import boto3
import logging
import os
from typing import Dict, Any, List

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize boto3 Fraud Detector client
frauddetector_client = boto3.client('frauddetector')

# Get configuration from environment variables (subtask 13.3)
DETECTOR_NAME = os.environ.get('DETECTOR_NAME', 'veritas_onboard_detector')
EVENT_TYPE_NAME = os.environ.get('EVENT_TYPE_NAME', 'onboarding_request')
MODEL_VERSION = os.environ.get('MODEL_VERSION', '1.0')


def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    Lambda function to assess fraud risk using Amazon Fraud Detector.
    
    Args:
        event: Input event containing requestId, email, ipAddress, and vendorName
        context: Lambda context object
    
    Returns:
        Dictionary containing fraud score, model version, and risk factors
    """
    try:
        # Extract input parameters
        request_id = event.get('requestId', 'unknown')
        email = event.get('email', '')
        ip_address = event.get('ipAddress', '')
        vendor_name = event.get('vendorName', '')
        
        logger.info(f"Processing fraud detection for request: {request_id}")
        logger.info(f"Using detector: {DETECTOR_NAME}, event type: {EVENT_TYPE_NAME}")
        
        # Call Fraud Detector get_event_prediction API
        response = get_fraud_prediction(
            detector_name=DETECTOR_NAME,
            event_type_name=EVENT_TYPE_NAME,
            email=email,
            ip_address=ip_address,
            vendor_name=vendor_name,
            event_id=request_id
        )
        
        # Parse fraud score from response
        fraud_score = parse_fraud_score(response)
        
        # Extract risk factors from model outcomes
        risk_factors = extract_risk_factors(response)
        
        # Get model version from response or use environment variable
        model_version = response.get('modelScores', [{}])[0].get('modelVersion', MODEL_VERSION)
        
        logger.info(f"Fraud detection completed for request {request_id}: score={fraud_score}, model={model_version}")
        
        return {
            'fraudScore': fraud_score,
            'modelVersion': model_version,
            'riskFactors': risk_factors
        }
        
    except Exception as e:
        # Error handling with default scoring
        logger.warning(f"Fraud Detector error for request {request_id}: {str(e)}")
        return handle_fraud_detector_error(e, request_id)


def get_fraud_prediction(
    detector_name: str,
    event_type_name: str,
    email: str,
    ip_address: str,
    vendor_name: str,
    event_id: str
) -> Dict[str, Any]:
    """
    Call Amazon Fraud Detector get_event_prediction API.
    
    Args:
        detector_name: Name of the Fraud Detector detector
        event_type_name: Name of the event type
        email: Contact email address
        ip_address: Source IP address
        vendor_name: Vendor/account name
        event_id: Unique event identifier (request ID)
    
    Returns:
        Fraud Detector API response
    """
    # Prepare event variables for Fraud Detector
    event_variables = {
        'email_address': email,
        'ip_address': ip_address,
        'account_name': vendor_name
    }
    
    # Call get_event_prediction
    response = frauddetector_client.get_event_prediction(
        detectorId=detector_name,
        eventId=event_id,
        eventTypeName=event_type_name,
        eventVariables=event_variables,
        entities=[{
            'entityType': 'customer',
            'entityId': email
        }]
    )
    
    return response


def parse_fraud_score(response: Dict[str, Any]) -> float:
    """
    Parse fraud score from Fraud Detector response.
    
    Args:
        response: Fraud Detector API response
    
    Returns:
        Fraud score in range 0.0 to 1.0
    """
    # Extract model scores from response
    model_scores = response.get('modelScores', [])
    
    if not model_scores:
        logger.warning("No model scores found in response, using default score")
        return 0.5
    
    # Get the first model score (primary model)
    primary_model = model_scores[0]
    scores = primary_model.get('scores', {})
    
    # Extract fraud score - typically returned as a key-value pair
    # The score key might vary based on model configuration
    fraud_score = None
    
    # Try common score keys
    for key in ['fraud_score', 'risk_score', 'score']:
        if key in scores:
            fraud_score = float(scores[key])
            break
    
    # If no score found, check ruleResults for outcomes
    if fraud_score is None:
        rule_results = response.get('ruleResults', [])
        for rule in rule_results:
            outcomes = rule.get('outcomes', [])
            if outcomes:
                # Use first outcome as indicator (high risk = 0.8, medium = 0.5, low = 0.2)
                outcome_name = outcomes[0].lower()
                if 'high' in outcome_name or 'block' in outcome_name:
                    fraud_score = 0.8
                elif 'medium' in outcome_name or 'review' in outcome_name:
                    fraud_score = 0.5
                elif 'low' in outcome_name or 'approve' in outcome_name:
                    fraud_score = 0.2
                break
    
    # Ensure score is in valid range
    if fraud_score is None:
        logger.warning("Could not parse fraud score from response, using default")
        fraud_score = 0.5
    else:
        fraud_score = max(0.0, min(1.0, fraud_score))
    
    return fraud_score


def extract_risk_factors(response: Dict[str, Any]) -> List[str]:
    """
    Extract risk factors from Fraud Detector model outcomes.
    
    Args:
        response: Fraud Detector API response
    
    Returns:
        List of risk factor strings
    """
    risk_factors = []
    
    # Extract from rule results
    rule_results = response.get('ruleResults', [])
    for rule in rule_results:
        if rule.get('outcomes'):
            rule_id = rule.get('ruleId', 'unknown_rule')
            risk_factors.append(rule_id)
    
    # Extract from model scores if available
    model_scores = response.get('modelScores', [])
    for model in model_scores:
        model_name = model.get('modelName', '')
        if model_name:
            # Add high-scoring model indicators
            scores = model.get('scores', {})
            for score_key, score_value in scores.items():
                try:
                    if float(score_value) > 0.7:
                        risk_factors.append(f"high_{score_key}")
                except (ValueError, TypeError):
                    pass
    
    # Check for specific risk indicators in response
    if 'high_risk_ip' in str(response).lower():
        risk_factors.append('high_risk_ip')
    if 'suspicious_email' in str(response).lower():
        risk_factors.append('suspicious_email_domain')
    
    return risk_factors


def handle_fraud_detector_error(error: Exception, request_id: str) -> Dict[str, Any]:
    """
    Handle Fraud Detector API errors with default scoring.
    
    Args:
        error: Exception that occurred
        request_id: Request identifier for logging
    
    Returns:
        Default response with fraud score of 0.5
    """
    error_type = type(error).__name__
    error_message = str(error)
    
    # Log detailed error information
    logger.warning(
        f"Fraud Detector API error for request {request_id}: "
        f"Type={error_type}, Message={error_message}"
    )
    
    # Check for specific error types
    if 'Throttling' in error_type or 'throttling' in error_message.lower():
        logger.warning(f"Fraud Detector throttling detected for request {request_id}")
    elif 'ServiceUnavailable' in error_type or 'unavailable' in error_message.lower():
        logger.warning(f"Fraud Detector service unavailable for request {request_id}")
    
    # Return default response with 0.5 fraud score
    return {
        'fraudScore': 0.5,
        'modelVersion': 'default',
        'riskFactors': ['error_default_score'],
        'error': error_type
    }
